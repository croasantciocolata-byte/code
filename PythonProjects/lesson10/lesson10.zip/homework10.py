try:
    name = input("Enter your name: ")
except ValueError:
    print("Name cannot be empty.") # nu imi arata aceasta eroare cand pun spatiu la name
except ValueError as e:
    print("Error:", e)
finally:
    print("Input process completed.")

try:
    age = input("Enter your age:")
    age = int(age)
except ValueError:
        print("Age must be a number.")
except ValueError as e:
    print("Error:", e)
finally:
    print("Input process completed.")